var classOnlineMapsGoogleDirectionsResult_1_1Fare =
[
    [ "currency", "classOnlineMapsGoogleDirectionsResult_1_1Fare.html#a400a996e9ca21b195f9fdca2d9f4ef37", null ],
    [ "text", "classOnlineMapsGoogleDirectionsResult_1_1Fare.html#adb7ef1b76d8dd2086d5b29c92a16c69f", null ],
    [ "value", "classOnlineMapsGoogleDirectionsResult_1_1Fare.html#ad01753b9fea2f25f222b0b31bb6429f2", null ]
];