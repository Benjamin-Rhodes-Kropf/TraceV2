var classOnlineMapsElevationManager =
[
    [ "RequestNewElevationData", "classOnlineMapsElevationManager.html#ae9d8f4df992978bd97bb12d7862eaa69", null ],
    [ "SetElevationData", "classOnlineMapsElevationManager.html#a066519fbf6574d05616ae3654755c2ec", null ],
    [ "isEnabled", "classOnlineMapsElevationManager.html#a299859ab6a8ccec09c109bb59de9f69c", null ]
];