var searchData=
[
  ['segment_1516',['Segment',['../classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html',1,'OnlineMapsOpenRouteServiceDirectionResult']]],
  ['snaptoroadresult_1517',['SnapToRoadResult',['../classOnlineMapsGoogleRoads_1_1SnapToRoadResult.html',1,'OnlineMapsGoogleRoads']]],
  ['speedlimitresult_1518',['SpeedLimitResult',['../classOnlineMapsGoogleRoads_1_1SpeedLimitResult.html',1,'OnlineMapsGoogleRoads']]],
  ['stateprops_1519',['StateProps',['../structOnlineMapsBuffer_1_1StateProps.html',1,'OnlineMapsBuffer']]],
  ['step_1520',['Step',['../classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html',1,'OnlineMapsOpenRouteServiceDirectionResult.Step'],['../classOnlineMapsGoogleDirectionsResult_1_1Step.html',1,'OnlineMapsGoogleDirectionsResult.Step']]],
  ['summary_1521',['Summary',['../classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary.html',1,'OnlineMapsOpenRouteServiceDirectionResult']]]
];
