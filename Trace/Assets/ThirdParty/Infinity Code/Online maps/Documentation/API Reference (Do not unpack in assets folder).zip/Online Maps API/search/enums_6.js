var searchData=
[
  ['requesttype_2584',['RequestType',['../classOnlineMapsWWW.html#a851a436cdda6e08a8522f4a870405e03',1,'OnlineMapsWWW']]],
  ['rooftype_2585',['RoofType',['../classOnlineMapsBuildingBase.html#a7b68fdef2c1d983da3c2395129b07a9c',1,'OnlineMapsBuildingBase']]]
];
