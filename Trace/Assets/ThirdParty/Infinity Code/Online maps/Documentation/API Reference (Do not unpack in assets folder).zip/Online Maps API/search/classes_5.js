var searchData=
[
  ['fare_1325',['Fare',['../classOnlineMapsGoogleDirectionsResult_1_1Fare.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['feature_1326',['Feature',['../classOnlineMapsOpenRouteServiceGeocodingResult_1_1Feature.html',1,'OnlineMapsOpenRouteServiceGeocodingResult']]]
];
